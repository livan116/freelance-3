document.addEventListener('DOMContentLoaded', function() {
  const navbar = document.getElementById('navbar');
  const mobileMenu = document.getElementById('mobile-menu');
  const mobileMenuButton = document.getElementById('mobile-menu-button');
  const mobileCloseButton = document.querySelector('.mobile-close-button');
  
  // Store the original height of navbar to maintain consistency
  const originalHeight = navbar.offsetHeight;
  
  // Set initial navbar position with space at top
  navbar.style.position = 'relative';
  navbar.style.top = '40px'; // Initial space at the top
  
  // Handle scroll behavior
  window.addEventListener('scroll', function() {
    if (window.scrollY > 40) {
      // When scrolled, fix the navbar to top
      navbar.style.position = 'fixed';
      navbar.style.top = '0';
      navbar.style.left = '0';
      navbar.style.right = '0';
      navbar.classList.add('scrolled'); // Add class for styling when scrolled
    } else {
      // Return to initial position when at top
      navbar.style.position = 'relative';
      navbar.style.top = (40 - window.scrollY) + 'px';
      navbar.classList.remove('scrolled'); // Remove scrolled class
    }
    
    // Ensure height remains consistent
    navbar.style.height = originalHeight + 'px';
  });
  
  // Mobile menu toggle
  mobileMenuButton.addEventListener('click', function() {
    mobileMenu.classList.remove('translate-x-full');
    document.body.style.overflow = 'hidden'; // Prevent scrolling when menu is open
  });
  
  mobileCloseButton.addEventListener('click', function() {
    mobileMenu.classList.add('translate-x-full');
    document.body.style.overflow = ''; // Re-enable scrolling
  });
  
  // Close mobile menu on window resize (if screen becomes large enough for desktop menu)
  window.addEventListener('resize', function() {
    if (window.innerWidth >= 768) { // md breakpoint in Tailwind
      mobileMenu.classList.add('translate-x-full');
      document.body.style.overflow = '';
    }
  });
  
  // Navigation active state
  const navLinks = document.querySelectorAll(".nav-line");
  const currentPage = window.location.pathname;
  
  navLinks.forEach((link) => {
    if (link.getAttribute("href") === currentPage) {
      link.classList.add("active");
      link.classList.add("text-[#9AC339]");
    }
  });
});



// gallery start

document.addEventListener("DOMContentLoaded", function () {
  const carousel = document.getElementById("carousel");
  const prevBtn = document.getElementById("prev-btn");
  const nextBtn = document.getElementById("next-btn");
  const indicators = document.querySelectorAll(".indicator-dot");

  let currentIndex = 0;
  const itemWidth = 100; // Width in percentage
  let itemsPerView = 1;
  let isDragging = false;
  let startPos = 0;
  let currentTranslate = 0;
  let prevTranslate = 0;
  let animationID = 0;
  let startIndex = 0;

  function updateItemsPerView() {
    if (window.innerWidth >= 1024) {
      itemsPerView = 3;
    } else if (window.innerWidth >= 640) {
      itemsPerView = 2;
    } else {
      itemsPerView = 1;
    }
  }

  function updateCarousel() {
    const translateX = -currentIndex * (itemWidth / itemsPerView);
    carousel.style.transform = `translateX(${translateX}%)`;
    prevTranslate = translateX;

    // Update indicators
    indicators.forEach((dot, index) => {
      if (Math.floor(currentIndex / itemsPerView) === index) {
        dot.classList.add("bg-opacity-100");
        dot.classList.remove("bg-opacity-50");
      } else {
        dot.classList.add("bg-opacity-50");
        dot.classList.remove("bg-opacity-100");
      }
    });
  }

  // Drag functionality
  function touchStart(event) {
    startPos = getPositionX(event);
    isDragging = true;
    startIndex = currentIndex;
    
    // Stop any ongoing animation
    cancelAnimationFrame(animationID);
    
    // Add event listeners for touch/mouse move and end
    document.addEventListener('mousemove', touchMove);
    document.addEventListener('touchmove', touchMove);
    document.addEventListener('mouseup', touchEnd);
    document.addEventListener('touchend', touchEnd);
    
    // Prevent default behavior to avoid text selection during drag
    event.preventDefault();
    
    // Add grabbing cursor
    carousel.style.cursor = 'grabbing';
  }

  function touchMove(event) {
    if (isDragging) {
      const currentPosition = getPositionX(event);
      const diff = currentPosition - startPos;
      
      // Convert pixel diff to percentage diff
      const containerWidth = carousel.clientWidth;
      const percentageDiff = (diff / containerWidth) * 100;
      
      // Calculate new translate value
      currentTranslate = prevTranslate + percentageDiff;
      
      // Set transform with the new translate value
      carousel.style.transform = `translateX(${currentTranslate}%)`;
    }
  }

  function touchEnd() {
    isDragging = false;
    
    // Remove event listeners
    document.removeEventListener('mousemove', touchMove);
    document.removeEventListener('touchmove', touchMove);
    document.removeEventListener('mouseup', touchEnd);
    document.removeEventListener('touchend', touchEnd);
    
    // Reset cursor
    carousel.style.cursor = 'grab';
    
    // Calculate how many items to move
    const totalItems = carousel.children.length;
    const movedPercentage = prevTranslate - currentTranslate;
    const threshold = 10; // Percentage threshold to trigger slide change
    
    if (Math.abs(movedPercentage) > threshold) {
      if (movedPercentage > 0) {
        // Moved right
        currentIndex = Math.min(startIndex + 1, totalItems - itemsPerView);
      } else {
        // Moved left
        currentIndex = Math.max(startIndex - 1, 0);
      }
    }
    
    // Animate slide to proper position
    updateCarousel();
  }

  function getPositionX(event) {
    return event.type.includes('mouse') ? event.pageX : event.touches[0].clientX;
  }

  // Add event listeners for drag
  carousel.addEventListener('mousedown', touchStart);
  carousel.addEventListener('touchstart', touchStart);
  
  // Set cursor style
  carousel.style.cursor = 'grab';
  
  // Prevent drag conflicts
  carousel.addEventListener('dragstart', (e) => e.preventDefault());

  // Button controls
  prevBtn.addEventListener("click", function () {
    if (currentIndex > 0) {
      currentIndex--;
      updateCarousel();
    }
  });

  nextBtn.addEventListener("click", function () {
    const totalItems = carousel.children.length;
    if (currentIndex < totalItems - itemsPerView) {
      currentIndex++;
      updateCarousel();
    }
  });

  // Indicator controls
  indicators.forEach((dot, index) => {
    dot.addEventListener("click", function () {
      currentIndex = index * itemsPerView;
      updateCarousel();
    });
  });

  // Update on resize
  window.addEventListener("resize", function () {
    updateItemsPerView();
    updateCarousel();
  });

  // Initial setup
  updateItemsPerView();
  updateCarousel();
});

// gallery end


// onsite and online services - fixed
document.addEventListener('DOMContentLoaded', function() {
  // Function to create carousel functionality
  function setupCarousel(sliderId, prevBtnId, nextBtnId, dotsContainerId) {
    const slider = document.getElementById(sliderId);
    const prevBtn = document.getElementById(prevBtnId);
    const nextBtn = document.getElementById(nextBtnId);
    const dotsContainer = document.getElementById(dotsContainerId);
    
    let currentPosition = 0;
    let itemsPerView = 1;
    let itemWidth = 100; // percentage width of items on mobile
    const totalItems = slider.children.length-1;
    let maxPositions = totalItems - itemsPerView;
    
    // Create dots based on number of pages
    function createDots() {
      dotsContainer.innerHTML = '';
      const pages = Math.ceil(totalItems / itemsPerView);
      
      for(let i = 0; i < pages; i++) {
        const dot = document.createElement('div');
        dot.classList.add('dot');
        if(i === 0) dot.classList.add('active');
        
        dot.addEventListener('click', () => {
          currentPosition = i * itemsPerView;
          if(currentPosition > maxPositions) currentPosition = maxPositions;
          moveSlider();
          updateDots();
        });
        
        dotsContainer.appendChild(dot);
      }
    }
    
    // Update active dot
    function updateDots() {
      const activePage = Math.floor(currentPosition / itemsPerView);
      const dots = dotsContainer.querySelectorAll('.dot');
      
      dots.forEach((dot, index) => {
        if(index === activePage) {
          dot.classList.add('active');
        } else {
          dot.classList.remove('active');
        }
      });
    }
    
    function updateView() {
      if (window.innerWidth >= 1024) {
        itemsPerView = 3;
        itemWidth = 33.333;
      } else if (window.innerWidth >= 640) {
        itemsPerView = 2;
        itemWidth = 50;
      } else {
        itemsPerView = 1;
        itemWidth = 100;
      }
      
      maxPositions = totalItems - itemsPerView;
      if(currentPosition > maxPositions) currentPosition = maxPositions;
      
      createDots();
      moveSlider();
    }
    
    function moveSlider() {
      // FIX: Calculate position based on full slide width
      // Each item should take up itemWidth percentage of the container
      const position = currentPosition * itemWidth;
      slider.style.transform = `translateX(-${position}%)`;
      updateDots();
      
      // Enable/disable buttons based on position
      if(currentPosition <= 0) {
        prevBtn.classList.add('opacity-50', 'cursor-not-allowed');
        prevBtn.disabled = true;
      } else {
        prevBtn.classList.remove('opacity-50', 'cursor-not-allowed');
        prevBtn.disabled = false;
      }
      
      if(currentPosition >= maxPositions) {
        nextBtn.classList.add('opacity-50', 'cursor-not-allowed');
        nextBtn.disabled = true;
      } else {
        nextBtn.classList.remove('opacity-50', 'cursor-not-allowed');
        nextBtn.disabled = false;
      }
    }
    
    prevBtn.addEventListener('click', function() {
      if (currentPosition > 0) {
        currentPosition--;
        moveSlider();
      }
    });
    
    nextBtn.addEventListener('click', function() {
      if (currentPosition < maxPositions) {
        currentPosition++;
        moveSlider();
      }
    });
    
    // Improve touch swipe functionality
    let touchStartX = 0;
    let touchEndX = 0;
    let isSwiping = false;
    
    slider.addEventListener('touchstart', (e) => {
      touchStartX = e.changedTouches[0].screenX;
      isSwiping = true;
    }, {passive: true});
    
    slider.addEventListener('touchmove', (e) => {
      if (!isSwiping) return;
      
      const currentX = e.changedTouches[0].screenX;
      const diff = currentX - touchStartX;
      
      // Optional: Add visual feedback during swipe
      // This creates a subtle drag effect
      const maxDragOffset = 50; // Limit how far items can be dragged
      const dragOffset = Math.max(Math.min(diff, maxDragOffset), -maxDragOffset);
      const dragPercentage = (dragOffset / slider.offsetWidth) * 100;
      
      const basePosition = currentPosition * itemWidth;
      slider.style.transform = `translateX(-${basePosition - dragPercentage}%)`;
    }, {passive: true});
    
    slider.addEventListener('touchend', (e) => {
      touchEndX = e.changedTouches[0].screenX;
      handleSwipe();
      isSwiping = false;
    }, {passive: true});
    
    function handleSwipe() {
      const swipeThreshold = 50;
      if(touchEndX < touchStartX - swipeThreshold) {
        // Swipe left -> next slide
        if(currentPosition < maxPositions) {
          currentPosition++;
          moveSlider();
        } else {
          // Bounce animation if at the end
          moveSlider();
        }
      } else if(touchEndX > touchStartX + swipeThreshold) {
        // Swipe right -> prev slide
        if(currentPosition > 0) {
          currentPosition--;
          moveSlider();
        } else {
          // Bounce animation if at the beginning
          moveSlider();
        }
      } else {
        // Not enough movement to count as swipe, reset position
        moveSlider();
      }
    }
    
    // Update on resize
    window.addEventListener('resize', function() {
      updateView();
    });
    
    // Initial setup
    updateView();
  }
  
  // Set up both carousels
  setupCarousel('onsite-services', 'onsite-prev', 'onsite-next', 'onsite-dots');
  setupCarousel('online-services', 'online-prev', 'online-next', 'online-dots');
});
// onsite and online services end


// testimonial carousel start

$(document).ready(function(){
  $('.testimonial-carousel').slick({
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    prevArrow: $('.prev-arrow'),
    nextArrow: $('.next-arrow'),
    draggable: true,
    swipe: true,
    touchMove: true,
    responsive: [
      {
        breakpoint: 1440,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          prevArrow: $('.prev-arrow'),
          nextArrow: $('.next-arrow'),
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          prevArrow: $('.mobile-prev'),
          nextArrow: $('.mobile-next')
        }
      }
    ]
  });

  // Connect mobile buttons to carousel
  $('.mobile-prev').click(function() {
    $('.testimonial-carousel').slick('slickPrev');
  });
  
  $('.mobile-next').click(function() {
    $('.testimonial-carousel').slick('slickNext');
  });
});
// testimonial carousel end

// modal start
document.addEventListener('DOMContentLoaded', function() {
  const bmiButton = document.querySelector('.bmi');
  const modal = document.getElementById('bmiModal');
  const closeModal = document.getElementById('closeModal');
  const calculateBtn = document.getElementById('calculateBtn');
  const clearBtn = document.getElementById('clearBtn');
  const bmiResult = document.getElementById('bmiResult');
  const ageInput = document.getElementById('age');
  const heightInput = document.getElementById('height');
  const weightInput = document.getElementById('weight');
  const maleRadio = document.getElementById('male');
  const femaleRadio = document.getElementById('female');
  const bmiCategories = document.getElementById("bmiCategories");
  
  // Open modal when BMI button is clicked
  bmiButton.addEventListener('click', function() {
    modal.classList.remove('hidden');
  });
  
  // Close modal when X button is clicked
  closeModal.addEventListener('click', function() {
    modal.classList.add('hidden');
  });
  
  // Close modal when clicking outside the modal content
  modal.addEventListener('click', function(e) {
    if (e.target === modal || e.target.classList.contains('bg-opacity-50')) {
      modal.classList.add('hidden');
    }
  });
  
  // Calculate BMI when the Calculate button is clicked
  calculateBtn.addEventListener('click', function() {
    const height = parseFloat(heightInput.value);
    const weight = parseFloat(weightInput.value);
    const age = parseInt(ageInput.value);
    const selectedGender = maleRadio.checked ? "male" : "female";
    
    // Validate mandatory fields
    if (isNaN(age) || age <= 0) {
      bmiResult.textContent = "Please enter a valid age";
      bmiResult.style.color = "red";
      bmiCategories.textContent = "";
      return;
    }
    
    if (!isNaN(height) && !isNaN(weight) && height > 0 && weight > 0) {
      // BMI formula: weight (kg) / (height (m))^2
      const heightInMeters = height / 100;
      const bmi = (weight / (heightInMeters * heightInMeters)).toFixed(1);
      bmiResult.innerHTML = `${bmi} <p>kg/m2</p>`;
      bmiResult.style.color = "black";
      let category = getBMICategory(age, selectedGender, bmi);
      bmiCategories.textContent = category;
    } else {
      bmiResult.textContent = "Please enter valid height and weight";
      bmiResult.style.color = "red";
      bmiCategories.textContent = "";
    }
  });

  function getBMICategory(age, gender, bmi) {
    if (age >= 18) {
      if (bmi < 18.5) return "Underweight";
      if (bmi >= 18.5 && bmi < 24.9) return "Normal weight";
      if (bmi >= 25 && bmi < 29.9) return "Overweight";
      return "Obese";
    } else {
      let percentileRanges = {
        male: {
          2: [14.0, 18.0, 20.5],
          3: [14.2, 18.2, 20.8],
          4: [14.3, 18.4, 21.1],
          5: [14.5, 18.6, 21.4],
          6: [14.6, 18.8, 21.7],
          7: [14.8, 19.0, 22.0],
          8: [14.9, 19.2, 22.3],
          9: [15.0, 19.4, 22.6],
          10: [15.2, 19.6, 22.9],
          11: [15.4, 19.9, 23.3],
          12: [15.6, 20.2, 23.7],
          13: [16.0, 20.6, 24.2],
          14: [16.4, 21.0, 24.7],
          15: [16.7, 21.4, 25.2],
          16: [17.0, 21.8, 25.7],
          17: [17.2, 22.2, 26.2]
        },
        female: {
          2: [13.8, 17.8, 20.2],
          3: [14.0, 18.0, 20.5],
          4: [14.1, 18.2, 20.8],
          5: [14.3, 18.4, 21.1],
          6: [14.5, 18.6, 21.4],
          7: [14.6, 18.8, 21.7],
          8: [14.8, 19.0, 22.0],
          9: [15.0, 19.2, 22.3],
          10: [15.2, 19.4, 22.6],
          11: [15.4, 19.7, 23.0],
          12: [15.7, 20.0, 23.4],
          13: [16.0, 20.4, 23.9],
          14: [16.3, 20.8, 24.4],
          15: [16.6, 21.2, 24.9],
          16: [16.9, 21.6, 25.4],
          17: [17.1, 22.0, 25.9]
        }
      };

      if (percentileRanges[gender] && percentileRanges[gender][age]) {
        let ranges = percentileRanges[gender][age];
        if (bmi < ranges[0]) return "Underweight";
        if (bmi < ranges[1]) return "Healthy weight";
        if (bmi < ranges[2]) return "Overweight";
        return "Obese";
      } else {
        return "Age out of range for BMI categories";
      }
    }
  }

  // Function to clear the data
  clearBtn.addEventListener('click', function() {
    ageInput.value = "";
    heightInput.value = "";
    weightInput.value = "";
    bmiResult.textContent = "";
    bmiResult.style.color = ""; // Reset text color if it was changed
    bmiCategories.textContent = "";
    // Reset radio buttons to default (male)
    maleRadio.checked = true;
    femaleRadio.checked = false;
  });
});
// modal end